CREATE TRIGGER SUB_MENU_ID_SQN_TRG
  BEFORE INSERT
  ON SUB_MENUS
  FOR EACH ROW
  begin     if inserting then       if :NEW."SUB_MENU_ID" is null then          select SUB_MENU_ID_SQN.nextval into :NEW."SUB_MENU_ID" from dual;       end if;    end if; end;
/

