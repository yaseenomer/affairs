CREATE VIEW EMP_VIEW AS
  SELECT e.EMP_NO,e.EMP_NAME,sex,RELIGION ,
MERITAL,HIRE_DATE,HIRE_LETTER_NO,HIRE_LETTER_DATE,cd.col_no,
cd.dep_no,cd.name
FROM  e, el, cd
where e.emp_no=el.emp_no and el.col_no=cd.col_no
and el.dep_no=cd.dep_no  and
(e.contract=0 or e.contract is null)
and el.app_date=(select max(app_date)
from el where emp_no=e.emp_no)
and el.col_no not in(21)
/

