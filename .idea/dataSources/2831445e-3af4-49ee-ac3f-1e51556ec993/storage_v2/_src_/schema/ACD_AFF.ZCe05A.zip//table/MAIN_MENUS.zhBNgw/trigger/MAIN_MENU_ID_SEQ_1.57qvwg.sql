CREATE TRIGGER MAIN_MENU_ID_SEQ_1
  BEFORE INSERT
  ON MAIN_MENUS
  FOR EACH ROW
  begin     if inserting then       if :NEW."MAIN_MENU_ID" is null then          select MAIN_MENU_ID_SQN.nextval into :NEW."MAIN_MENU_ID" from dual;       end if;    end if; end;
/

