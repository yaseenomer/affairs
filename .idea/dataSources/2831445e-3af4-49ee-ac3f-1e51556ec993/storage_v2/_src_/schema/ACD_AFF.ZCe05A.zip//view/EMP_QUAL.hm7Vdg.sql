CREATE VIEW EMP_QUAL AS
  select e.emp_no,e.emp_name,eq.ISSUE_DATE,eq.note
FROM eq , e
where  e.emp_no=eq.emp_no
/

