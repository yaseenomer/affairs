CREATE VIEW V_$OSSTAT AS
  select "STAT_NAME","VALUE","OSSTAT_ID" from v$osstat
/

