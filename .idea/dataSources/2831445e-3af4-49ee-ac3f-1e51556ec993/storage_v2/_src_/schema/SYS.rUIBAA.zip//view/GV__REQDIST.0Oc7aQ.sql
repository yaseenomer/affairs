CREATE VIEW GV_$REQDIST AS
  select "INST_ID","BUCKET","COUNT" from gv$reqdist
/

