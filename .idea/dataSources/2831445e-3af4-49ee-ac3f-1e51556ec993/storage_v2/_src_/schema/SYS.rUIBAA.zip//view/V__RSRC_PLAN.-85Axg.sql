CREATE VIEW V_$RSRC_PLAN AS
  select "ID","NAME","IS_TOP_PLAN" from v$rsrc_plan
/

