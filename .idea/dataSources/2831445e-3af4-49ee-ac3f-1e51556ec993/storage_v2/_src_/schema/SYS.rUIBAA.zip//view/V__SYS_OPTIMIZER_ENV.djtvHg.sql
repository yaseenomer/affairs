CREATE VIEW V_$SYS_OPTIMIZER_ENV AS
  select "ID","NAME","ISDEFAULT","VALUE","DEFAULT_VALUE" from v$sys_optimizer_env
/

