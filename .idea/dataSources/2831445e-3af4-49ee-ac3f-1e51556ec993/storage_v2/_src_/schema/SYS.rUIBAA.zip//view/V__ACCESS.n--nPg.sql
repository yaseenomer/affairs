CREATE VIEW V_$ACCESS AS
  select "SID","OWNER","OBJECT","TYPE" from v$access
/

