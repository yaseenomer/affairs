CREATE VIEW GV_$SGASTAT AS
  select "INST_ID","POOL","NAME","BYTES" from gv$sgastat
/

