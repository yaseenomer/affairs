CREATE VIEW GV_$FIXED_TABLE AS
  select "INST_ID","NAME","OBJECT_ID","TYPE","TABLE_NUM" from gv$fixed_table
/

