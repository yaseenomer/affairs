CREATE VIEW GV_$PWFILE_USERS AS
  select "INST_ID","USERNAME","SYSDBA","SYSOPER" from gv$pwfile_users
/

