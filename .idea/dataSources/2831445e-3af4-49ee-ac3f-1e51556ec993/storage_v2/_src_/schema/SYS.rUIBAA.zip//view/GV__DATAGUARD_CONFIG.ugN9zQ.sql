CREATE VIEW GV_$DATAGUARD_CONFIG AS
  select "DB_UNIQUE_NAME" from gv$dataguard_config
/

