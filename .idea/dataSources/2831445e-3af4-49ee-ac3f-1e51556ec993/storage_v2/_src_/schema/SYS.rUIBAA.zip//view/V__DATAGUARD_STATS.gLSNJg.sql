CREATE VIEW V_$DATAGUARD_STATS AS
  select "NAME","VALUE","UNIT","TIME_COMPUTED" from v$dataguard_stats
/

