CREATE VIEW GV_$BACKUP AS
  select "INST_ID","FILE#","STATUS","CHANGE#","TIME" from gv$backup
/

