CREATE VIEW GV_$CLUSTER_INTERCONNECTS AS
  select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$cluster_interconnects
/

