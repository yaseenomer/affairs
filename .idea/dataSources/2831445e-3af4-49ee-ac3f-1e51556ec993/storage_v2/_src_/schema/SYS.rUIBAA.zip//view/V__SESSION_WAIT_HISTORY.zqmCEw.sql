CREATE VIEW V_$SESSION_WAIT_HISTORY AS
  select "SID","SEQ#","EVENT#","EVENT","P1TEXT","P1","P2TEXT","P2","P3TEXT","P3","WAIT_TIME","WAIT_COUNT" from v$session_wait_history
/

