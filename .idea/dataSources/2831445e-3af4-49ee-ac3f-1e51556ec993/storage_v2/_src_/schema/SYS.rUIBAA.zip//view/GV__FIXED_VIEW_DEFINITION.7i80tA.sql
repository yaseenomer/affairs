CREATE VIEW GV_$FIXED_VIEW_DEFINITION AS
  select "INST_ID","VIEW_NAME","VIEW_DEFINITION" from gv$fixed_view_definition
/

