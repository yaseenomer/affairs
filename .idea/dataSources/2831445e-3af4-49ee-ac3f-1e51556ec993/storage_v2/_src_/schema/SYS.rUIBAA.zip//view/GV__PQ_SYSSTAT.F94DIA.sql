CREATE VIEW GV_$PQ_SYSSTAT AS
  select "INST_ID","STATISTIC","VALUE" from gv$pq_sysstat
/

