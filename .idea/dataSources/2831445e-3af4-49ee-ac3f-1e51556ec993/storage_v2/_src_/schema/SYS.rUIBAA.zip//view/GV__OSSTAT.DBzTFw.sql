CREATE VIEW GV_$OSSTAT AS
  select "INST_ID","STAT_NAME","VALUE","OSSTAT_ID" from gv$osstat
/

