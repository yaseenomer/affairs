CREATE VIEW GV_$PARAMETER_VALID_VALUES AS
  select "INST_ID","NUM","NAME","ORDINAL","VALUE","ISDEFAULT" from gv$parameter_valid_values
/

