CREATE VIEW V_$PWFILE_USERS AS
  select "USERNAME","SYSDBA","SYSOPER" from v$pwfile_users
/

