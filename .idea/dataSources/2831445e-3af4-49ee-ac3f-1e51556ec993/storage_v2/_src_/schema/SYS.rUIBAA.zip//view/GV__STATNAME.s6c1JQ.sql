CREATE VIEW GV_$STATNAME AS
  select "INST_ID","STATISTIC#","NAME","CLASS","STAT_ID" from gv$statname
/

