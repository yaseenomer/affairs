CREATE VIEW GV_$QUEUE AS
  select "INST_ID","PADDR","TYPE","QUEUED","WAIT","TOTALQ" from gv$queue
/

