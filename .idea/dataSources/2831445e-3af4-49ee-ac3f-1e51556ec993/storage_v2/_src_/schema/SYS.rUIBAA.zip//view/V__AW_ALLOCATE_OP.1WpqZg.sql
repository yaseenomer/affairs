CREATE VIEW V_$AW_ALLOCATE_OP AS
  select "NAME","LONGNAME" from v$aw_allocate_op
/

