CREATE VIEW GV_$TIMER AS
  select "INST_ID","HSECS" from gv$timer
/

