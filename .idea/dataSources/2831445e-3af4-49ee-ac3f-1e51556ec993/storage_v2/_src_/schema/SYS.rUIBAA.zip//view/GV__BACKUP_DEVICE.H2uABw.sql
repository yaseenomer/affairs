CREATE VIEW GV_$BACKUP_DEVICE AS
  select "INST_ID","DEVICE_TYPE","DEVICE_NAME" from gv$backup_device
/

