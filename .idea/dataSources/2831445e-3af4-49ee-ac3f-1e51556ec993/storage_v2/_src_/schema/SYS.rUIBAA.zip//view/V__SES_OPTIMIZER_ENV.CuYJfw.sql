CREATE VIEW V_$SES_OPTIMIZER_ENV AS
  select "SID","ID","NAME","ISDEFAULT","VALUE" from v$ses_optimizer_env
/

