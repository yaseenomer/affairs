CREATE VIEW V_$OBSOLETE_PARAMETER AS
  select "NAME","ISSPECIFIED" from v$obsolete_parameter
/

