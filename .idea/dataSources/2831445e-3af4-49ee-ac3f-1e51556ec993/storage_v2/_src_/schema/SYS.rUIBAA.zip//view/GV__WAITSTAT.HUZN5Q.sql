CREATE VIEW GV_$WAITSTAT AS
  select "INST_ID","CLASS","COUNT","TIME" from gv$waitstat
/

