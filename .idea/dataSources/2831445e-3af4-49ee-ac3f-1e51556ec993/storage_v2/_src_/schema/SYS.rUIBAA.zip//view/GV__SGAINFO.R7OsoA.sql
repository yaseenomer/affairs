CREATE VIEW GV_$SGAINFO AS
  select "INST_ID","NAME","BYTES","RESIZEABLE" from gv$sgainfo
/

